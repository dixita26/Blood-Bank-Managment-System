<?php
$db=new PDO('mysql:host=localhost;dbname=blood bank','root','');
if($db)
{
    echo "";
}
else
{
    echo "not connected";
}
?>