<!DOCTYPE html>
<html>
<head>
      <title>Blood Bank Home</title>
      <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
   <div class="header">
     <div class="logo"><h2>Blood Bank Management<h2> </div>
       <div class="nav">
           <div id="a"><a href="index.php">Home</a></div>
           <div id="b"><a href="about.php">About</a></div>
           <div id="c"><a href="contact.php">Contact Us</a></div>
           <div id="d"><a href="login.php">Login</a></div>
      </div>
  </div>
 
  <div class="body">
         <br><br><br><br><br>
         <table align="center" > 
             <tr>
                 <td width="250px" height="70px"><b>Enetr Username</b></td>
                <td width="250px" height="70px"><input type="text" name="un" placeholder="Enter Username" 
                style="width: 180px; height: 30px; border-radius:10px;"></td>
             </tr>
             <tr>
                <td width="250px" height="70px"><b>Enetr Password<b></td>
                <td width="250px" height="70px"><input type="text" name="pswd" placeholder="Enter password"
                style="width: 180px; height: 30px; border-radius:10px;"
                ></td>
             </tr>
             <tr>
                 <td height="70px" align="right"><input type="submit" name="submit" value="Login" style="width:70px; height: 30px;
                  border-radius:5px;"></td>
             </tr>
         </table>
         <br><br><br><br>
         </div>       
         <br><br><br><br>
         <br><br><br><br>

      <div class="footer"><h2 align="center">Copyright@2019-20</h2></div>
</body>
</html>