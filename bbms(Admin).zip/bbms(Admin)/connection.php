<?php
$db=new PDO('mysql:host=localhost;dbname=mypro_bbms','root','');
if($db)
{
    echo "";
}
else
{
    echo "not connected";
}
?>