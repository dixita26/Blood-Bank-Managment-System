<?php
include('connection.php');
session_start();
?>
<html>
<head>
<title>NGO List</title>
<link rel="stylesheet" type="text/css" href="css/s1.css">
</head>
<body>
<div id="full">
    <div id="inner_full">
       <div id="header" align="center"><h2><a href="admin-home.php" style="text-decoration:none; color:black;"></a>Blood Bank </h2></div>
       <div id="body">
           <br>
           <?php
           $un=$_SESSION['un'];
           if(!$un)
           {
               header("Location:index.php");
           }
           ?>
            <h1>NGO List</h1><br><br>
           
       </div>
       <div id="footer"><p align="center"><a href="logout.php"><font color="black"><h3 align="center">Logout</h3></a></p></div>
           
</body>
</html>