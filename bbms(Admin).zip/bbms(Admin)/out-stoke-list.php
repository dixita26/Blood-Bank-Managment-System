<?php
include('connection.php');
session_start();
?>
<html>
<head>
<title>out-stoke-list</title>
<link rel="stylesheet" type="text/css" href="css/s1.css">
<style type="text/css">
    td{
        width:200px;
        height:40px;
    }
</style>
</head>
<body>
<div id="full">
    <div id="inner_full">
       <div id="header" align="center"><h2><a href="admin-home.php" style="text-decoration:none; color:black;"></a>Blood Bank </h2></div>
       <div id="body">
           <?php
           $un=$_SESSION['un'];
           if(!$un)
           {
               header("Location:index.php");
           }
           ?>
            <h2 align="center">Out Stoke Blood List</h2><br><br>
            <center><div id="form">
                <table>
                    <tr>
                        <td><center><b><font color="navy">Name</font></b></center></td>
                        <td><center><b><font color="navy">Mobile No</font></b></center></td>
                        <td><center><b><font color="navy">Blood Group</font></b></center></td>
                    </tr>
                    <?php 
                    $q=$db->query("SELECT * FROM out_stoke_b");
                    while($r1=$q->fetch(PDO::FETCH_OBJ))
                    {
                        ?>
                    <tr>
                        <td><center><?= $r1->name; ?></center></td>
                        <td><center><?= $r1->mno; ?></center></td>
                        <td><center><?= $r1->bname; ?></center></td>
                    
                    </tr>
                    
                    <?php
                    }   
                    ?>
                </table>
            </div></center>
       </div>
       <div id="footer"><p align="center"><a href="logout.php"><font color="black"><h3 align="center">Logout</h3></a></p></div>
           
</body>
</html>